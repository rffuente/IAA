#ifndef read_matrix_h
#define read_matrix_h

using namespace std;

//This function read the data file and load the content into an integer 
//matrix (vector of vectors).
vector<vector<int> > read_matrix(string route);

#endif 